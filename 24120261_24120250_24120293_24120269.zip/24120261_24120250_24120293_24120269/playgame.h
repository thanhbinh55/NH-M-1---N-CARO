﻿#pragma once
#include <iostream>
#include <conio.h>
#include <Windows.h>
#include "Menu.h"
#include "Help.h"
int menu();
void ShowCur(bool CursorVisibility);
void ResetData();
void Check_new_game();

void return_menu() {
	int choice = menu();
	ShowCur(true);
	switch (choice)
	{
	case 0:
		Check_new_game();
		system("cls");
		ShowCur(true);
		Play_Game();
		break;
	case 1: //Load game
		/*Load(_A, Player_1, Player_2, _TURN, "C:\\Users\\Admin\\Desktop\\text.txt"); */
		break;
	case 2:
		break;
	case 3:
		system("cls");
		Help(10, 10, 80, 30);
		break;
	case 4:
		ExitGame();
		break;
	}

	system("pause"); //FixConsoleWindow(); // KHONG RO O DAY CO TAC DUNG NHU THE NAO
}


