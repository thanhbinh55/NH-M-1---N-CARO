﻿#pragma once
#include <iostream>
#include <string>
#include <fstream>

using namespace std;


void Save(_POINT _A[BOARD_SIZE][BOARD_SIZE], const Player& Player_1, const Player& Player_2, bool _TURN, const string& FileName) // Doc va ghi File --> luu Game vao file
{
    //-------------------------------------------------SAVE GAME----------
    ofstream outputFile(FileName, ios::app);
    if (!outputFile)
    {
        cerr << "Khong the mo File de ghi!" << endl;
        return;
    }

    //Luu ban co
    for(int j = 0; j < BOARD_SIZE; j++)
    {
        for (int i = 0; i < BOARD_SIZE;i++)
        {
            outputFile << _A[i][j].c << " ";//outputFile << _A[i][j]. --> THIẾU .c là sai --> có thể sửa bằng một số cách khác nhau Như định nghĩa toán tử
        }
        outputFile << endl;
    }

    //Luu thong so nguoi choi
    outputFile << Player_1.Name << " " << Player_1.Moves << " " << Player_1.Wins << endl;
    outputFile << Player_2.Name << " " << Player_2.Moves << " " << Player_2.Wins << endl;
    outputFile << _TURN << endl;

    outputFile.close();
}

void Load(_POINT _A[BOARD_SIZE][BOARD_SIZE], Player Player_1, Player Player_2, bool _TURN, const string& FileName)
{
    // doc --> luu --> hien thi

    ifstream inputFile(FileName);
    if (!inputFile)
    {
        cerr << "Khong the mo File de doc!" << endl;
        return;
    }
    //Doc ban co
    for (int j = 0; j < BOARD_SIZE; j++)
    {
        for (int i = 0; i < BOARD_SIZE; i++)
        {
            inputFile >> _A[i][j].c;//outputFile << _A[i][j]. --> THIẾU .c là sai --> có thể sửa bằng một số cách khác nhau Như định nghĩa toán tử
        }
    }

    //Luu thong so nguoi choi
    inputFile >> Player_1.Name >>  Player_1.Moves  >> Player_1.Wins ;
    inputFile >> Player_2.Name >>  Player_2.Moves  >> Player_2.Wins ;
    inputFile >> _TURN;

    inputFile.close();
}
