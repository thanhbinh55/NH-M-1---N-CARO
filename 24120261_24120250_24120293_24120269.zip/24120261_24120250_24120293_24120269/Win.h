﻿#pragma once
#include <iostream>
#include <cstdlib> // Thư viện để sử dụng hàm system("clear") hoặc system("cls")
#include <thread>  // Thư viện để sử dụng hàm sleep_for
#include <chrono>  // Thư viện để định nghĩa thời gian chờ

using namespace std;

// Hàm để thay đổi màu sắc bằng mã màu ANSI
void SettColor(int color) {
    cout << "\033[" << color << "m";
}

// Hàm để in chữ "WIN" với hiệu ứng lấp lánh
void printWin() {
    cout << "W       W  IIIII  N     N" << endl;
    cout << "W       W    I    NN    N" << endl;
    cout << "W   W   W    I    N N   N" << endl;
    cout << "W  W W  W    I    N  N  N" << endl;
    cout << "W W   W W    I    N   N N" << endl;
    cout << "WW     WW  IIIII  N     N" << endl;
}

void win() {
    while (true) {
        // Đổi màu đỏ
        setColor(31);
        system("cls"); // Dùng "cls" nếu chạy trên Windows
        printWin();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));

        // Đổi màu xanh lá
        setColor(32);
        system("cls");
        printWin();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));

        // Đổi màu vàng
        setColor(33);
        system("cls");
        printWin();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
    }

    // Reset lại màu về mặc định
    setColor(0);
    return;
}