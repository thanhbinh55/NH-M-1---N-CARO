﻿#pragma once
#include <iostream>
#include <cstdlib> // Thư viện để sử dụng hàm system("clear") hoặc system("cls")
#include <thread>  // Thư viện để sử dụng hàm sleep_for
#include <chrono>  // Thư viện để định nghĩa thời gian chờ

using namespace std;

string getC(int line) {
    switch (line) {
    case 1: return "  ***** ";
    case 2: return " *      ";
    case 3: return "*       ";
    case 4: return "*       ";
    case 5: return " *      ";
    case 6: return "  ***** ";
    default: return "";
    }
}

string getA(int line) {
    switch (line) {
    case 1: return "  ***   ";
    case 2: return " *   *  ";
    case 3: return "*     * ";
    case 4: return "******* ";
    case 5: return "*     * ";
    case 6: return "*     * ";
    default: return "";
    }
}

string getR(int line) {
    switch (line) {
    case 1: return " ******  ";
    case 2: return " *     * ";
    case 3: return " *     * ";
    case 4: return " ******  ";
    case 5: return " *   *   ";
    case 6: return " *    *  ";
    default: return "";
    }
}

string getO(int line) {
    switch (line) {
    case 1: return "  *****  ";
    case 2: return " *     * ";
    case 3: return "*       *";
    case 4: return "*       *";
    case 5: return " *     * ";
    case 6: return "  *****  ";
    default: return "";
    }
}


// Hàm để thay đổi màu sắc bằng mã màu ANSI
void setColor(int color) {
    cout << "\033[" << color << "m";
}

// Hàm để in chữ "WIN" với hiệu ứng lấp lánh
void printCaro() {
    for (int i = 1; i <= 6; i++) {
        cout << getC(i) << "  " << getA(i) << "  " << getR(i) << "  " << getO(i) << endl;
    }
}

void Title() {
    while (true) {
        // Đổi màu đỏ
        setColor(31);
        system("cls"); // Dùng "cls" nếu chạy trên Windows
        printCaro();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));

        // Đổi màu xanh lá
        setColor(32);
        system("cls");
        printCaro();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));

        // Đổi màu vàng
        setColor(33);
        system("cls");
        printCaro();
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
    }

    // Reset lại màu về mặc định
    setColor(0);
    return;
}