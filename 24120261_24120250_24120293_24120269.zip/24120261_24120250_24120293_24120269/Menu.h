﻿#pragma once
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <string>
#include <thread> // Thư viện để sử dụng std::this_thread::sleep_for
#include <chrono> // Thư viện cho thời gian
using namespace std;
void DrawBound(int x0, int y0, int h, int w);
int x = 50;
int y = 5;
int box_spacing = 1; // Giảm khoảng cách giữa các khung

// Hàm điều khiển con trỏ tới vị trí x, y trong console

void GotoXY(int x, int y);

// Hàm ẩn hoặc hiện con trỏ
void ShowCur(bool CursorVisibility) {
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
    cursorInfo.bVisible = CursorVisibility; // Ẩn hoặc hiện con trỏ
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
}

// Hàm thay đổi màu chữ
void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// Hàm tạo hộp (box) có đường viền và tô màu nền
void box(int x, int y, int w, int h, int t_color, int b_color, string nd) {
   system("color F0");
    // Tô màu nền lam cho tất cả các khung
    SetColor(b_color);
   // system("color F0");
    for (int iy = y; iy <= y + h ; iy++) {  // Bỏ "+1" và "-1"
        for (int ix = x; ix <= x + w; ix++) {
            GotoXY(ix, iy);
            cout << " "; // Tô đầy khung
        }
    }

    
    // Đặt màu chữ cho nội dung
   // SetColor(240); // Màu chữ trắng
    GotoXY(x + (w - nd.length()) / 2, y + h / 2); // Căn giữa nội dung
    cout << nd;

    // Vẽ viền
    SetColor(t_color);
   // SetColor(240);
    if (h <= 1 || w <= 1) return;

    for (int ix = x; ix <= x + w; ix++) {
        GotoXY(ix, y);
        cout << char(196);
        GotoXY(ix, y + h);
        cout << char(196);
    }
    for (int iy = y; iy <= y + h; iy++) {
        GotoXY(x, iy);
        cout << char(179);
        GotoXY(x + w, iy);
        cout << char(179);
    }

    GotoXY(x, y); cout << char(218);
    GotoXY(x + w, y); cout << char(191);
    GotoXY(x, y + h); cout << char(192);
    GotoXY(x + w, y + h); cout << char(217);
}

// Hàm vẽ thanh sáng khi chọn mục
void thanh_sang(int x, int y, int w, int h, int b_color_sang, string nd) {
    SetColor(b_color_sang); // Màu đậm hơn cho mục được chọn
    for (int iy = y + 1; iy <= y + h - 1; iy++) {
        for (int ix = x + 1; ix <= x + w - 1; ix++) {
            GotoXY(ix, iy);
            cout << " "; // Tô đầy
        }
    }

   // SetColor(252); // Màu chữ trắng --> bỏ dòng này thì chữ sẽ trở về màu cũ sau khi hết chọn 
    GotoXY(x + (w - nd.length()) / 2, y + h / 2); // Căn giữa nội dung
    cout << nd;
}


// Hàm tạo menu động
int menu() {
    //system("color F0");
    DrawBound(1, 1, 40, 150);

    ShowCur(false);

    // Cài đặt các thông số menu
    int w = 13; // Thu nhỏ chiều rộng của khung
    int h = 2;  // Chiều cao của khung giữ nguyên
    int t_color = 240; // Màu viền
    int b_color = 240; // Màu nền trắng, chữ đen
    int b_color_sang = 252; // Nền đỏ, chữ đen
    string items[] = { "New Game", "Load Game", "Setting", "Help", "Exit" };
    int sl = 5; // Số lượng mục menu

    // Vẽ menu ban đầu với khoảng cách nhỏ hơn giữa các khung
    for (int i = 0; i < sl; i++) {
        box(x, y + i * (h + box_spacing), w, h , t_color, b_color, items[i]);
    }

    int xp = x;
    int yp = y; // Tọa độ thanh sáng
    int xcu = xp;
    int ycu = yp;
    bool kt = true;

    while (true) {
        if (kt == true) {
            GotoXY(xcu, ycu);
            thanh_sang(xcu, ycu, w, h, b_color, items[(ycu - y) / (h + box_spacing)]);
            xcu = xp;
            ycu = yp;

            thanh_sang(xp, yp, w, h, b_color_sang, items[(yp - y) / (h + box_spacing)]);
            kt = false;
        }


        if (_kbhit()) {
            _COMMAND = toupper(_getch());
            kt = true;
            /* if (c == -32) {
                 kt = true;
                 c = _getch();*/
            if (_COMMAND == 'W') { // Lên
                if (yp != y)
                    yp -= (h + box_spacing);
                else
                    yp = y + (h + box_spacing) * (sl - 1);
            }
            else if (_COMMAND == 'S') { // Xuống
                if (yp != y + (h + box_spacing) * (sl - 1))
                    yp += (h + box_spacing);
                else
                    yp = y;
            }

            if (_COMMAND == 13) { // Enter
                // Thực thi hành động tương ứng khi nhấn Enter
                int index = (yp - y) / (h + box_spacing);
                cout << "\nYou selected: " << items[index] << endl;
                return index;

                // Loại bỏ phần màu đỏ (12) và thay bằng hành động hoặc thông báo
                std::this_thread::sleep_for(std::chrono::milliseconds(1000)); // Tạm dừng 1 giây
                break; // Thoát vòng lặp

            }

        }
    }
}