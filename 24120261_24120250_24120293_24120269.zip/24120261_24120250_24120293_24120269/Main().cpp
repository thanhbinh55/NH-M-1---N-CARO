﻿//Hằng số
#define BOARD_SIZE 15// Kích thức ma trận bàn cờ
#define LEFT 5 // Tọa độ trái màn hình bàn cờ //x
#define TOP 5// Tọa độ trên màn hình bàn cờ //y
// Khai báo kiểu dữ liệu
struct _POINT { int x, y, c; }; // x: tọa độ dòng, y: tọa độ cột, c: đánh dấu
_POINT _A[BOARD_SIZE][BOARD_SIZE]; //Ma trận bàn cờ
bool _TURN; //true là lượt người thứ nhất và false là lượt người thứ hai 
//1--> Player_1
//0--> Player_2
int _COMMAND; // Biến nhận giá trị phím người dùng nhập
int _X, _Y; //Tọa độ hiện hành trên màn hình bàn cờ

#include <iostream>
#include <string>
#include <conio.h> // Thư viện cho hàm getch()
#include <windows.h> // Thư viện để dùng hàm GotoXY và SetConsoleCursorPosition
#include "Menu.h"
#include "Help.h"
#include "playgame.h"
#include "Title_CAROh.h"
#include "Win.h"
//#include "Save_Load_Game.h"
using namespace std;

//Nguoi choi
struct Player {
	string Name;
	int Moves = 0;//so buoc di chuyen
	int Wins = 0;//so luoc thang


	void Thong_so_Players(int n) //n: chi so cua nguoi choi
	{
		cout << endl << "Nhap thong tin Players: " << endl;
		cout << "Name of Player_" << n << ": ";
		getline(cin, Name);
	}

	void In_thong_so_Player(int n)
	{
		cout << "Player_" << n << "'s Name: " << Name << endl;
	}
	void So_buoc_di_chuyen() {
		cout << "Moves: " << Moves << endl;
	}
	void So_lan_thang() {
		cout << "Wins: " << Wins << endl;
	}
};
//--------------Dùng tạm, sau này cần tổng quát hóa và gọn hơn chứ không khai báo như này

Player Player_1;
Player Player_2;

//#include "Save_Load_Game.h" // khai bao duoi ni la de truct Player duoc dinh nghia truoc 
//--> SAU NÀY XỬ LÝ GỌN GÀNG HƠN BẰNG CÁCH CHIA TÁCH FILE, 
//----------Khai báo hàm
//// Hàm nhóm View
void FixConsoleWindow();
void GotoXY(int x, int y);
//// hàm nhóm Model
void DrawBoard(int pSize);
void DrawBound(int Size);
int TestBoard();
bool isDraw();
bool checkWin(int x, int y);
void Check_new_game();
int CheckBoard(int pX, int pY); //hàm đánh dấu vào ma trận bàn cờ khi người chơi nhấn phím ‘enter

// Hàm nhóm Control
void StartGame();
void GabageCollect();
void ExitGame();
void MoveRight();
void MoveLeft();
void MoveDown();
void MoveUp();
////
void ResetData();
////Player
void Khoi_tao_Players(Player& Player_1, Player& Player_2, int n);
void Show_Player(int x, int y, int w, int h, int number_of_players);


//----------Định nghĩa hàm

void GotoXY(int x, int y) {
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void Khoi_tao_Players(Player& Player_1, Player& Player_2, int n)
{
	if (n == 1)
	{
		Player_1.Thong_so_Players(1);
	}
	else if (n == 2)
	{
		Player_1.Thong_so_Players(1);
		Player_2.Thong_so_Players(2);
	}
}
void Show_Player(int x, int y, int w, int h, int number_of_players)
{

	{
		if (number_of_players == 1)
		{
			Box(x, y, w, h);
			GotoXY(x + 2, y + 1);
			Player_1.In_thong_so_Player(1);
			GotoXY(x + 2, y + 2);
			Player_1.So_buoc_di_chuyen();
			GotoXY(x + 2, y + 3);
			Player_1.So_lan_thang();

		}
		else if (number_of_players == 2)
		{
			Box(x, y, w, h);
			GotoXY(x + 2, y + 1);
			Player_1.In_thong_so_Player(1);
			GotoXY(x + 2, y + 2);
			Player_1.So_buoc_di_chuyen();
			GotoXY(x + 2, y + 3);
			Player_1.So_lan_thang();

			Box(x + 45, y, w, h);
			GotoXY(x + 45 + 2, y + 1);
			Player_2.In_thong_so_Player(2);
			GotoXY(x + 45 + 2, y + 2);
			Player_2.So_buoc_di_chuyen();
			GotoXY(x + 45 + 2, y + 3);
			Player_2.So_lan_thang();
		}
	}

}

//// Hàm nhóm View
void FixConsoleWindow() {
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);
	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);
	SetWindowLong(consoleWindow, GWL_STYLE, style);
}

// Hàm xử lý khi người chơi thua
int ProcessFinish(int pWhoWin) {
	GotoXY(85 + 2, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 8); // Nhảy tới vị trí thích hợp để in chuỗi thắng/thua/hòa

	switch (pWhoWin) {

	case -1:
		Box(75, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 10, 70, 10);
		GotoXY(85 + 10, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 5);
		cout << "Player_1: " << Player_1.Name << " THANG" << " Player_2: " << Player_2.Name << endl;
		break;
	case 1:
		Box(75, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 10, 70, 10);
		GotoXY(85 + 10, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 5);
		cout << "Player_2: " << Player_2.Name << " THANG" << " Player_1: " << Player_1.Name << endl;
		break;
	case 0:
		Box(75, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 10, 70, 10);
		GotoXY(85 + 10, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 5);
		cout << "Player_1: " << Player_1.Name << " HOA" << " Player_2: " << Player_2.Name << endl;
		break;
	case 2:
		_TURN = !_TURN; // Đổi lượt nếu không có gì xảy ra
	}
	GotoXY(_X, _Y); // Trả về vị trí hiện hành của con trỏ màn hình bàn cờ
	return pWhoWin;
}

// Hàm hỏi người chơi có tiếp tục hay không
int AskContinue() {
	Box(75, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 20, 70, 6);
	GotoXY(75 + 10, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y - 18); // Nhảy đến vị trí để hỏi người chơi
	printf("Nhan 'y/n' de tiep tuc/dung: ");
	return toupper(_getch()); // Đọc ký tự và trả về dạng chữ hoa
}
//------------------------------------------------------------
//SAU KHI TAO GAME MOI THI THONG SO BUOC DANH DUOC CAP NHAT TIEP
//------------------------------------------------------------


void DrawBoard(int pSize)
{
	//ngang
	for (int ix = LEFT + 1; ix <= LEFT + pSize * 4 - 1; ix += 4)
	{
		for (int iy = TOP; iy <= TOP + pSize * 2; iy += 2)
		{
			GotoXY(ix, iy);
			cout << char(196);
			GotoXY(ix + 1, iy);
			cout << char(196);
			GotoXY(ix + 2, iy);
			cout << char(196);
		}
	}
	//doc
	for (int iy = TOP + 1; iy <= TOP + pSize * 2 - 1; iy += 2)
	{
		for (int ix = LEFT; ix <= LEFT + pSize * 4; ix += 4)
		{
			GotoXY(ix, iy);
			cout << char(179);
		}
	}
	//cong
	for (int ix = LEFT + 4; ix <= LEFT + pSize * 4; ix += 4)
	{
		for (int iy = TOP + 2; iy <= TOP + pSize * 2 - 2; iy += 2)
		{
			GotoXY(ix, iy);
			cout << char(197);
		}
	}
	//cong tren/duoi
	for (int ix = LEFT + 4; ix <= LEFT + pSize * 4; ix += 4)
	{
		GotoXY(ix, TOP);
		cout << char(194);
		GotoXY(ix, TOP + pSize * 2);
		cout << char(193);
	}
	//cong trai/phai
	for (int iy = TOP + 2; iy <= TOP + pSize * 2; iy += 2)
	{
		GotoXY(LEFT, iy);
		cout << char(195);
		GotoXY(LEFT + pSize * 4, iy);
		cout << char(180);
	}
	GotoXY(LEFT, TOP); cout << char(218);//goc tren tai
	GotoXY(pSize * 4 + LEFT, TOP); cout << char(191); //goc tren phai
	GotoXY(LEFT, TOP + pSize * 2); cout << char(192); //goc duoi trai
	GotoXY(LEFT + pSize * 4, TOP + pSize * 2); cout << char(217); //goc duoi phai
}
void DrawBound(int x0, int y0, int h, int w)
{
	//ngang
	for (int ix = x0 + 1; ix < x0 + w; ix++)
	{
		GotoXY(ix, y0);
		cout << char(196);
		GotoXY(ix, y0 + h);
		cout << char(196);
	}
	//doc
	for (int iy = x0 + 1; iy < y0 + h; iy++)
	{
		GotoXY(x0, iy);
		cout << char(179);
		GotoXY(x0 + w, iy);
		cout << char(179);
	}

	GotoXY(x0, y0); cout << char(218);
	GotoXY(x0 + w, y0); cout << char(191);
	GotoXY(x0, y0 + h); cout << char(192);
	GotoXY(x0 + w, y0 + h); cout << char(217);
}

//Hàm khởi tạo dữ liệu mặc định ban đầu cho ma trận bàn cờ (hàm nhóm Model)


void MoveRight() {
	if (_X < _A[BOARD_SIZE - 1][BOARD_SIZE - 1].x)
	{
		_X += 4;
		GotoXY(_X, _Y);
	}
}
void MoveLeft() {
	if (_X > _A[0][0].x) {
		_X -= 4;
		GotoXY(_X, _Y);
	}
}
void MoveDown() {
	if (_Y < _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y)
	{
		_Y += 2;
		GotoXY(_X, _Y);
	}
}
void MoveUp() {
	if (_Y > _A[0][0].y) {
		_Y -= 2;
		GotoXY(_X, _Y);
	}
}


bool isDraw() {
	// Kiểm tra nếu tất cả các ô trên bàn cờ đều đã được điền
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			if (_A[i][j].c == 0)  // Ô trống
				return false; //--> chua full
		}
	}
	return true;  // Hòa khi tất cả các ô đều đầy
}

bool checkWin(int x, int y) {
	int player = _A[x][y].c;  // Giá trị người chơi ở ô (x, y)

	int dem_1 = 0;
	int dem_2 = 0;
	int dem_3 = 0;
	int dem_4 = 0;

	//ngang
	for (int j = y; j < y + 5; j++)
	{
		if (_A[x][j].c == player) dem_1++;
	}

	//doc
	for (int i = x; i < x + 5; i++)
	{
		if (_A[i][y].c == player) dem_2++;
	}

	//cheo chinh
	for (int k = 0; k < 5; k++)
	{
		if (_A[k + x][k + y].c == player) dem_3++;
	}

	//cheo phu
	for (int k = 0; k < 5; k++)
	{
		if (_A[x - k][k + y].c == player) dem_4++;
	}

	// Nếu có đủ 5 quân liên tiếp
	if (dem_1 >= 5 || dem_2 >= 5 || dem_3 >= 5 || dem_4 >= 5) {
		return true;
	}

	return false;
}

int TestBoard() {
	// Kiểm tra điều kiện hòa
	if (isDraw()) {
		return 0;  // Hòa
	}

	// Kiểm tra điều kiện thắng
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			if (_A[i][j].c != 0 && checkWin(i, j)) {
				if (_TURN == true) {
					Player_1.Wins++;
					return -1;
				}
				else {
					Player_2.Wins++;
					return 1;
				}
				//return (_TURN == true ? -1 : 1);  // -1 là lượt người chơi 1 thắng, 1 là người chơi 2 thắng
			}
		}
	}
	return 2;  // 2 nghĩa là chưa ai thắng, trò chơi tiếp tục
}


//hàm đánh dấu vào ma trận bàn cờ khi người chơi nhấn phím ‘enter
//--> kiểm tra vị trí đánh _X, _y là của 1 hay 0
int CheckBoard(int pX, int pY) {
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			if (_A[i][j].x == pX && _A[i][j].y == pY && _A[i][j].c == 0) {
				if (_TURN == true) _A[i][j].c = -1; // Nếu lượt hiện hành là true thì c = -1
				else _A[i][j].c = 1; // Nếu lượt hiện hành là false thì c = 1
				return _A[i][j].c;
			}
		}
	}
	return 0;
}

void ResetData() {

	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			_A[i][j].x = 4 * j + LEFT + 2; // Trùng với hoành độ màn hình bàn cờ

			_A[i][j].y = 2 * i + TOP + 1; // Trùng với tung độ màn hình bàn cờ

			_A[i][j].c = 0; // 0 nghĩa là chưa ai đánh dấu, nếu đánh dấu phải theo quy 
			//định như sau: -1 là lượt true đánh, 1 là lượt false đánh					
		}
	}
	_TURN = true; _COMMAND = -1; // Gán lượt và phím mặc định
	_X = _A[0][0].x; _Y = _A[0][0].y; // Thiết lập lại tọa độ hiện hành ban đầu

}

// Hàm nhóm Control
void StartGame() {
	system("cls");
	ResetData(); // Khởi tạo dữ liệu gốc
	DrawBoard(BOARD_SIZE); // Vẽ màn hình game
	DrawBound(1, 1, 40, 150);
}

void Check_new_game() {
	int choice = menu();
	if (choice == 0) {
		Player_1.Moves = 0;
		Player_1.Wins = 0;
		Player_2.Moves = 0;
		Player_2.Wins = 0;
	}
}


//Hàm dọn dẹp tài nguyên (hàm nhóm Model)
void GabageCollect()
{
	// chuc ban thanh cong
}
//Hàm thoát game (hàm nhóm Control)

void ExitGame() {
	system("cls");
	GabageCollect();
	//Có thể lưu game trước khi exit
}

void Play_Game()
{
	FixConsoleWindow();
	//StartGame();
	bool validEnter = true;
	Khoi_tao_Players(Player_1, Player_2, 2);
	_flushall();
	StartGame();
	Show_Player(75, 7, 25, 4, 2);
	while (1) {
		/*Check_new_game();*/
		_COMMAND = toupper(_getch());
		if (_COMMAND == 27) { // 27 là mã của phím ESC
			return_menu();
			return;
		}
		else {
			if (_COMMAND == 'A') MoveLeft();
			else if (_COMMAND == 'W') MoveUp();
			else if (_COMMAND == 'S') MoveDown();
			else if (_COMMAND == 'D') MoveRight();
			else if (_COMMAND == 13) { // Người dùng nhấn Enter

				switch (CheckBoard(_X, _Y)) {
				case -1:
					printf("X");
					Player_1.Moves++;
					Show_Player(75, 7, 25, 4, 2);
					break;
				case 1:
					printf("O");
					Player_2.Moves++;
					Show_Player(75, 7, 25, 4, 2);
					break;
				case 0:
					validEnter = false; // Ô đã được đánh dấu trước đó
					break;
				}
				if (validEnter == true) {
					switch (ProcessFinish(TestBoard())) {
					case -1:
					case 1:
					case 0:
						if (AskContinue() != 'Y') {
							system("cls");
							return_menu();
						}
						else {
							StartGame();
						}
					}
				}
				validEnter = true; // Mở khóa cho lượt tiếp theo
			}
		}
	}
}

int main()
{

	//Title();//xoa comment de chay thu
	//win(); //xoa comment de chay thu
	int choice = menu();
	ShowCur(true);
	switch (choice)
	{
	case 0:
		system("cls");
		Play_Game();

	case 1: //Load game chua hoan thien nen chua goi ham duoc
		//Load(_A, Player_1, Player_2, _TURN, "C:\\Users\\Admin\\Desktop\\text.txt"); 
		break;
	case 2:
		while (1) {
			_COMMAND = toupper(_getch());
			if (_COMMAND == 27) { // 27 là mã của phím ESC
				system("cls");
				return_menu();
				//ExitGame();
			}
		}
		break;
	case 3:
		system("cls");
		Help(10, 10, 80, 30);
		_COMMAND = toupper(_getch());
		if (_COMMAND == 27) { // 27 là mã của phím ESC
			return_menu();
		}
		break;
	case 4:
		ExitGame();
		system("pause");
		break;
	}
	system("pause");
	return 0;
}